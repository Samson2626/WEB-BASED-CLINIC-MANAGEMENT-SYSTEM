
from sqlalchemy import create_engine,text



 
engine = create_engine('mysql://root:@localhost/clinicc')
def tryy():
    global cp
    try:
        connection = engine.connect()
        cp=1
    except Exception as e:
        cp=0    

    

      
dk={
     'fname': "bbeteu",
        'sname': "rdaand",
        'pw': "02124",
        'address': 1004,
        'statuss': 3,
        'jop_id': 3
    }

def pull(quer):
    
    with engine.connect() as conn:
        tryy()
        query = text(quer)
        result = conn.execute(query)
        return result
        
    
   
    
    
   
def insert_update_and_DELETE(quer,dk):#to insert valuse
    with engine.connect() as conn:
        tryy()
        query = text(quer)
        conn.execute(query, dk)
        conn.commit()



      
 
