from flask import Flask, render_template,request
from maindb import pull,insert_update_and_DELETE
import mysql.connector
import datetime
import math
#anime************************
def equation(x):
  m = (29241 / 100) * x
  lk = {}
  lk["r"] = int((255 / 100) * x)
  lk["g"] = int(math.sqrt(m))
  lk["b"] = int(-(73 / 2500) * (x - 50)**2 + 73)
  return lk
x_values = list(range(0, 101))
l_t = {}
for x in x_values:
  l_t[x] = equation(x)
conn=mysql.connector.connect(host="localhost",user="root",password="",database="clinicc")
if conn.is_connected():
  print("KK")
else:
  print("ss")
p=4
TB1={}
TB2={}
x2={}
ntc=0
wid=0
mh1=0
ID1="0"
ID2="0"
la_r_c=1
url={"slg":"0","bck1":"0","bck2":"0"}
ACC={"name":"0",
     "id":"0",
     "stu":"0",
     "pw":"0",
      "ACCT":"0"} 
PAA={"Name":"0",
      "id":"0",
      "Age":"0",
      "Sex":"0",
     "Name":"0",
     "address":"0"
     }
care={}
TG={}
FM= {"1":"2"}
patern={}
MU={}
LT={"1":"2"}
CM={"1":"2" }
LG="0"
AC="#"
nav={"1":"2"}
tebl_ad={"1":"2" }
tost={"1":"2"}
MFA={}
jp=9
sb_minput="submit"
comp_t={"1":"2"}
comp={"1":"2"}
tb_ab1={"1":"2"}
def befr():
  global FM,MU,LT,CM,LG,AC,TB1,TB2,nav,tebl_ad,TG,tost,MFA,comp,ntc,patern,comp_t,sb_minput,tb_ab1
  TB1={"1":"2"}
  sb_minput="submit"
  comp_t={"1":"2"}
  comp={"1":"2"}
  nav={"1":"2"}
  tb_ab1={"1":"2"}
  MFA={}
  patern={}
  TB2={}
  FM={"1":"2"}
  MU={}
  LT={"1":"2"}
  tebl_ad={"1":"2" }
  CM={"1":"2" }
  LG="0"
  AC="#"
  TG={}
  tost={"1":"2"}
  PAA={"Name":"0",
      "id":"0",
      "Age":"0",
      "Sex":"0",
     "Name":"0",
     "address":"0"
     }

def worksel(em_i):
       global FM,CM,wid
       
       quer=em_i
       conj=pull(quer)
       
       
       
       conj=conj.fetchall()
       
       if len(conj) == 0:
        CM={"no petionent":""}
       else:
        FM={"petionet":" "}
        X2={}
        le=0
        
        for x in conj:
         le=45
         print("00000000000000000000098818")
         quer="SELECT fname,	sname    FROM petionet WHERE id= '" +str( x[0]) + "' "
         con=pull(quer)
         Y=con.fetchone()
         x1=Y[0]+" "+Y[1]
         print("000000",x1)
         X4={x1:  x[1]}
         X2.update(X4)
        """"
        if(le==0):
           quer="SELECT fname,	sname    FROM petionet WHERE id= '" +str( row[0]) + "' "
           con=pull(quer)
           Y=con.fetchone()
           X2={Y[0]+" "+Y[1]:row[1]}
           """
        FM["petionet"]=X2 
        CM={"select petionet":""} 
        
def SELECTIV(conj):
  x2={}
  for x in conj:
    x1=x[0]+" "+x[1]
    x4={x1:str(x[2])}
    x2.update(x4)    
  return x2

def ITRFUN(conj):
  x=0
  for y in conj:
    x=y
  return x
def passw1():
  global FM,CM,patern
  patern={"insert old pass word":"[A-Za-z0-9]{1,20}", "insert new pass word":"[A-Za-z0-9]{1,20}", "check pass word":"[A-Za-z0-9]{1,20}" }
  FM={
      "insert old pass word":"2",
      "insert new pass word":"2",
      "check pass word":"2"
      
    }
  CM={"Insert the form":" "}
def passw2():
  global CM,ACC
  sa = request.form
  print(sa)
  if(sa["insert old pass word"]==ACC["pw"]):
      if(sa["insert new pass word"]==sa["check pass word"]):
        quer="UPDATE employe SET pw = :pw WHERE id = :id"
        dk=[{'pw': sa["insert new pass word"], 'id':ACC["id"]}]
        insert_update_and_DELETE(quer,dk)
        ACC["pw"]= sa["insert new pass word"]
        CM={"SECCSEFULY!":" "} 
      else:
        CM={"The pass word is not mach":" "}
  else:
      CM={"The pass word is not corect":" "}

def stu_1(x):
   if int (x)==1:
      y="Administrator"
   if int (x)==2:
      y="Card room"
      
   if int(x)==3:
      y="Outpatient department"
      
   if int(x)==4:
      y="laboratory"
          
   if int(x)==5:
      y="pharmacy"
   return y 
def comp_ch():
    quer="SELECT seen FROM comp "
    conj=pull(quer)
    k=0
    for x in conj:
      
      if(str(x[0])=="1"):
        k=k+1
        
    return k
def in_lb_ch():
    global ACC
    quer="SELECT 	id    FROM work WHERE em_id='" +str(ACC["id"]) + "' " 
    conj=pull(quer)
    k=0
    for x in conj:
         k=k+1
        
    return k
def in_ch_lb():
    global ACC
    quer="SELECT p_id   FROM  work WHERE lab_stu ='3' AND em_id='" +str(ACC["id"]) + "'  "
    conj=pull(quer)
    k=0
    for x in conj:
         k=k+1
        
    return k
def in_lb_c() :
    global ACC 
    quer="SELECT p_id,	id    FROM work WHERE jp_id='4' AND  emp_id_l='" +str(ACC["id"]) + "'  "
    
    conj=pull(quer)
    k=0
    for x in conj:
         k=k+1
        
    return k
  
def stu_2(x):
   if int (x)==2:
      y="fas fa-clipboard-list"
   if int(x)==3:
      y="fas fa-user-md"
   if int(x)==4:
      y="fas fa-microscope"  
   if int(x)==5:
      y="fas fa-capsules"
   return y



def date_diff( sstr,estr ):
    sstr=str(sstr)
    estr=  str(estr)
    print("cccf1c",estr)
    m=""
    c=""
    for x in sstr:
      if( x=="-"):
        break
      else:
        m=m+x
        print("cccfc",m)
    for x in estr:
      if( x=="-"):
        break
      else:
        c=c+x
        print("cccic",c)
    p=int(c)-int(m)
    return p
def list_pp(x):
  global TB2
  quer="SELECT *  FROM petionet WHERE id= '" + str(x) + "'"
  conj=pull(quer)
  conj=conj.fetchone()
  
  TB2={}
  TB2["Name"]=conj[1] +" "+conj[2]
  TB2["UGR"]=conj[4]
  TB2["Address"]=conj[5]
  TB2["sex"]=conj[6]
  start_date_str = str(conj[7])
  end_date_str = datetime.datetime.now().date()
  m= date_diff(start_date_str, end_date_str)
  
  TB2["Age"]=conj[3]+m
def comp_rest():
     global ACC,AC,comp_t,comp
     quer="UPDATE comp SET seen_re = :seen_re WHERE emp_id = :emp_id "
     dk=[{"emp_id":ACC["id"], "seen_re":"0"}]
     insert_update_and_DELETE(quer,dk)
     if(jp==0):
      sa = request.form
      
      quer="INSERT INTO comp (Complin, reply, seen, emp_id) VALUES (:Complin, :reply, :seen, :emp_id);"
      dk=[{'reply': "#0101", 'Complin':str(sa["name"]),"seen":"1","emp_id":str(ACC["id"])}]
      insert_update_and_DELETE(quer,dk)
      AC="#"
     y={}
     y1={}
     quer="SELECT *   FROM  comp WHERE emp_id='" +str(ACC["id"]) + "'"
     conj=pull(quer)
     conj=conj.fetchall()
       
     if len(conj) == 0:
        CM={"new Complin":""}
     else:
      for x in conj:
       y1[x[1]]=x[2].replace('\r\n', '')
       print("ss",y1)
     y["3"]=stu_2(ACC["ACCT"])
     y["2"]=y1
     y["1"]=ACC["name"]
     comp=y
     comp_t={"1":"3"}
   
      
      
     print("comp",comp)

###############################  
def admin():
  global MU,FM ,AC,CM,nav,tebl_ad,TG,tost,MFA,comp,patern,jp,tb_ab1
  k1=comp_ch()
  
  
  dt= datetime.datetime.now().date()
  id=ACC["ACCT"]
  m=stu_1(id)
  dt= datetime.datetime.now().date()
  TG={
    "1":ACC["name"],
    "2":m,
    "3":dt,
    "4":'Administrator.PNG'
   
    }
  MFA={"Account":"fas fa-user","patient":"fas fa-procedures","profile":"fas fa-users","Complin":"fas fa-clipboard-list"}
  if k1 !=0:
    k11="you have "+str(k1)+" "+"new Complin"
    tost= {"1":k11} 
    MFA["Complin"]="far fa-bell"
    print(MFA)
  MU={
            "Account":{"Create":"/1/1",
                   "status":"/1/2"
                    },
            
            "patient":"/1/8",
            "Complin":"/1/9",
              "profile":{"change password":"/1/3"}
            }
  if (ID1=="1"):
   
   nav= {"0":"Create",
          "1":{"Create":"/1/1",
          "status":"/1/2",
             "List":"/1/7"}
           }
   patern={"Name":"[A-Za-z]{1,20}","Scond Name":"[A-Za-z]{1,20}","pohone":"[0][9][0-9]{1,8}" ,"Pass Word":"[A-Za-z0-9]{1,20}"}
   FM={
      "Name":"2",
      "Scond Name":"2",
      "Pass Word" :"2",
      "pohone":"2",
       "care":{
        "Outpatient department":"3",
        "Card Room":"2",
        "laboratory":"4",
        "pharmacy":"5"
           }
      
      }
   CM={"insert informetion":""}
   if(jp==0):
    sa = request.form
    quer="SELECT fname   FROM  employe WHERE address='" +str(sa["pohone"]) + "'"
   
    conj=pull(quer)
    X=()
    for x in conj:
      X=x
    if len(X) != 0:
        tost={"1":"warning exiting staf! "} 
    else:
        
        
    
        quer="INSERT INTO employe (fname, sname, pw, address, statuss, jop_id) VALUES (:fname, :sname, :pw, :address, :statuss, :jop_id);"
        dk=[{"fname":sa["Name"],"sname":sa["Scond Name"],"pw":sa["Pass Word"],"address":sa["pohone"],"statuss":"1","jop_id":sa["care"]}]
        insert_update_and_DELETE(quer,dk)
        tost={"1":"SECCSEFULY! "} 
    AC="/1/1"
  if (ID1=="2"):
    nav= {"0":"status",
          "1":{"Create":"/1/1",
          "status":"/1/2",
          "List":"/1/7"}
           }
    
    print("ID1==2")
    quer="SELECT fname, sname,statuss  FROM employe "
    conj=pull(quer)
    FM={"09":""}
    x2={}
    print(conj)
    for y in conj:
      xs=y[0]+"  "+y[1]
      x1={xs:str(y[2])}
      x2.update(x1)
      
    FM["09"]=x2
    
    print(FM)
    
    CM={"Acconts":" "}
    if(jp==0):
      tost={"1":"SECCSEFULY! "}
      sa=request.form.getlist('lname')
      print("pppppppppp",sa)
    
     
      quer="SELECT fname, sname  FROM employe "
      conj=pull(quer)
    
    
      print(conj)
      for y in conj:
       m=1
       xs=y[0]+"  "+y[1]
       print(xs)
       for x in sa:
        
        if(xs==x):
          quer="UPDATE employe SET statuss = :statuss WHERE fname = :fname"
          dk=[{'statuss': "1", 'fname': y[0]}]
          insert_update_and_DELETE(quer,dk)
          m=0
          
        
          
      if(m==1):
        quer="UPDATE employe SET statuss = :statuss WHERE fname = :fname"
        dk=[{'statuss': "0", 'fname': y[0]}]
        insert_update_and_DELETE(quer,dk)
    AC="/1/2"
  if (ID1=="3"):
    passw1()
    
    


    AC="/1/6/1"
 
  if(ID1=="6"):
    passw2()
  if(ID1=="7"):
    quer="SELECT * FROM  employe "
    tb_ab1={"1":"Fname","2":"Sname","6":"status","4":"TELL_P"}
    conj=pull(quer)
    tebl_ad={ }
    M=0
    for x in conj:
      M1={}
      for v,v1 in tb_ab1.items():
        if(v=="6"):
          M1[v1]=stu_1(x[int(v)])
        else:
         M1[v1]=x[int(v)]
      tebl_ad[M]=M1
      M=M+1
   
   
    nav= {"0":"List",
          "1":{"Create":"/1/1",
          "status":"/1/2",
          "List":"/1/7"}
           }
  if(ID1=="8"):
    quer="SELECT * FROM petionet "
    tb_ab1={"1":"Fname","2":"Sname","5":"TELL_P","4":"UGR"}
    conj=pull(quer)
    tebl_ad={ }
    M=0
    for x in conj:
      M1={}
      for v,v1 in tb_ab1.items():
        M1[v1]=x[int(v)]
      tebl_ad[M]=M1
      M=M+1
    
    
  if(ID1=="9") :
     quer="UPDATE comp SET seen = 0;"
     dk=[]
     insert_update_and_DELETE(quer,dk)
     if(jp==0):
      sa = request.form
      for key, values in sa.items():
        quer="UPDATE comp SET reply = :reply WHERE id = :id"
        dk=[{'reply': str(values), 'id':key}]
        insert_update_and_DELETE(quer,dk)
      AC="/1/9"
     y={}
     quer="SELECT * FROM comp "
     conj=pull(quer)
     v=1
     for x in conj:
       y1={}
       y1["0"]=x[0]
       y1["1"]=x[1]
       y1["2"]=x[2].replace('\r\n', '')
       quer="SELECT fname,jop_id  FROM  employe WHERE id= '" +str(x[4]) + "' "
       con=pull(quer)
       con=con.fetchone()
       
       y1["3"]=stu_2(con[1])
       v1=con[0]+"...."+str(v)
       v=v+1
       y[v1]=y1
     comp=y
   
      
      
     print("comp",comp)
       
####################################
def cardroom():

  global MU,FM ,AC,CM,nav,tebl_ad,TG,tost,MFA,comp,p,patern,jp,tb_ab1
  
  dt= datetime.datetime.now().date()
  id=ACC["ACCT"]
  m=stu_1(id)
  dt= datetime.datetime.now().date()
  TG={
    "1":ACC["name"],
    "2":m,
    "3":dt,
    "4":'card_room.JPG'
   
    }
  
  MFA={ "Register patient":"fas fa-clipboard-list","patient":"fas fa-procedures","profile":"fas fa-users","Complin":"fas fa-clipboard-list"}
  MU={
    "Register patient":{
      "Add new record":"/1/1",
      "Send Requestes to OPD":"/1/2"
    },
    "patient":"/1/8",
     "Complin":"/1/9",
    "profile":{"change password":"/1/3"}

       }
  if(ID1=="1"):
    
    nav= {"0":"Add",
          "1":{"Add new record":"/1/1",
          "Send Requestes to OPD":"/1/2"
          }
           }
    patern={"Name":"[A-Za-z]{1,20}","Second Name":"[A-Za-z]{1,20}",
            "Address":"[0][9][0-9]{1,8}" ,
            "UGR":"UGR/[0-9]{5}/[0-9]{2}",
            "AGE":"[0-9]{2}"}
    FM={
       "Name":"2",
      "Second Name":"2",
      "UGR":"2",
      "Address":"2",
      "AGE":"2",

      "SEX":{"Male":"male",
              "Female":"female"}
    }
    if(jp==0):
      
     sa = request.form
     quer="SELECT fname   FROM  petionet WHERE ugr='" +str(sa["UGR"]) + "'"
   
     conj=pull(quer)
     X=()
     for x in conj:
      X=x
     if len(X) != 0:
       
        CM={"warning":"exiting patient! "} 
     else:
        
      sa = request.form
      quer="INSERT INTO petionet (fname, sname, age, 	ugr, 	address,sex,DATE) VALUES (:fname, :sname, :age, :ugr, :address, :sex,:DATE);"
      DEL=datetime.datetime.now().date()
      DEL=str(DEL)
     
      dk=[{"fname":sa["Name"],"sname":sa["Second Name"],"age":sa["AGE"],"ugr":sa["UGR"],"address":sa["Address"],"sex":sa["SEX"] , "DATE":DEL}]
      insert_update_and_DELETE(quer,dk)
      CM={"patient registration":"SECCSEFULY!"} 
      AC="/1/1"
  if(ID1=="2"):
   nav= {"0":"Send",
          "1":{"Add new record":"/1/1",
          "Send Requestes to OPD":"/1/2"
          }
           }
   patern={"UGR":"UGR/[0-9]{5}/[0-9]{2}"}
   FM={"UGR":"2"}
   CM={"Insert UGR":" "}
   if(jp==0):
    sa = request.form
    dt= datetime.datetime.now().date()
    print("dateeeeeeee",dt)
    quer="INSERT INTO mh (DATE, petionet_id , employe_id ) VALUES ( :date, :petiont, :employ);"
    dk=[ {"date":dt, "petiont":p ,"employ":sa["OPD"] }]
    insert_update_and_DELETE(quer,dk)
    quer="SELECT id FROM mh WHERE DATE = '" +str( dt)+ "' AND petionet_id = '"+str(p)  +"'"
    conj=pull(quer)
    idx=ITRFUN(conj)
    idx=idx[0]
    quer="INSERT INTO work (lab_stu, p_id ,mh_id , 	jp_id,	em_id  ) VALUES (:lab_stu, :p_id, :mh_id,:jp_id,:em_id);"
    dk=[{"lab_stu":0,"p_id":p ,"mh_id":idx,"jp_id":3,"em_id":sa["OPD"] }]
    insert_update_and_DELETE(quer,dk)
    CM={"request sent":"SECCSEFULY! "} 
   AC="/1/5/A"
  if(ID1=="3"):
    passw1()
    AC="/1/6/A"
 
 
  if(ID1=="5"):
    sa = request.form
    quer="SELECT fname, sname, id FROM petionet WHERE ugr= '" + sa["UGR"] + "' "
    conj=pull(quer)
    X=ITRFUN(conj)
  
    if X == 0:
      CM={"No student in this ugr":" "}
    else:
      
      p=X[2]
      quer="SELECT fname, sname,id FROM employe  WHERE 	statuss= '1' AND jop_id='3'"
      conj=pull(quer)
      FM={"OPD":" "}
      
      bb=dict(SELECTIV(conj))
      FM["OPD"]=bb
      Y=X[0]+" "+X[1]
      CM={" petionet Name":Y}
      
      AC="/1/2"
  if(ID1=="6"):
    passw2()
 

  if(ID1=="8"):
    quer="SELECT * FROM petionet "
    tb_ab1={"1":"Fname","2":"Sname","5":"TELL_P","4":"UGR"}
    conj=pull(quer)
    tebl_ad={ }
    M=0
    for x in conj:
      M1={}
      for v,v1 in tb_ab1.items():
        M1[v1]=x[int(v)]
      tebl_ad[M]=M1
      M=M+1
  if(ID1=="9"):
    
    comp_rest()


###############################
def o_P_D():
   global MU,FM ,AC,CM,nav,tebl_ad,TG,tost,MFA,comp,TB1,TB2,ntc,sb_minput,jp
   global LT,PAA,mh1,wid
   k1=in_lb_ch()
   k2=in_ch_lb()
   
   dt= datetime.datetime.now().date()
   id=ACC["ACCT"]
   m=stu_1(id)
   dt= datetime.datetime.now().date()
   TG={
    "1":ACC["name"],
    "2":m,
    "3":dt,
    "4":'doc.JPG'}
  
  
   MFA={ "laboratory":"fas fa-microscope","patient":"fas fa-procedures","profile":"fas fa-users","patient info":"fas fa-clipboard-list","Complin":"fas fa-clipboard-list"}
   if k1 !=0:
    MFA["patient"]="far fa-bell"
    if (ntc==0):
     k11="you have "+str(k1)+" "+"new patient"
     tost= {"1":k11} 
     ntc=1
   if k2 !=0:
     MFA["laboratory"]="far fa-bell"
   MU={
     "patient":"/1/1",
     "patient info":{"View-p-info":"/1/2",
                       "New M-H":"/1/3",
                       },
      "laboratory":"/1/10",
      "Complin":"/1/13",
      "profile":{"change password":"/1/6"}

   }
   
     
   if(ID1=="1"):
    
    em_i="SELECT p_id,	id    FROM work WHERE em_id='" +str(ACC["id"]) + "' "  
    worksel(em_i)
    sb_minput="Ditale"
    AC="/1/7/A"
   if(ID1=="2"):
  
     if(PAA["Name"]=="0"):
       CM={"no petionent":""}
     else:
       CM={"Name  "+PAA["Name"]:""}
       
       
       
       
       TB1={"a":"11"}
       x=PAA["id"]
       list_pp(x)
   if(ID1=="3"):
     
    if(PAA["id"]=="0"):
       CM={"no petionent":""}
    else:
     nav= {"0":"New",
          "1":{
               "View-M-H-info":"/1/12",
               "New M-H":"/1/3",
               "laboratory reqwest ":"/1/4"
          }
           }
     FM={
       "Diagnosis":"1",
       "Prescription":"1",
       "Comment":"1"}
     CM={"Name":PAA["Name"]}
     AC="/1/8/A"
   if(ID1=="4"):
     if(PAA["id"]=="0"):
       CM={"no petionent":""}
     else:
       nav= {"0":"laboratory",
          "1":{
               "View-M-H-info":"/1/12",
               "New M-H":"/1/3",
               "laboratory reqwest":"/1/4"
          }
           }
       CM={"Name  "+PAA["Name"]:""}
       FM={"09":{"Urinalysis color":"urinalysis color",
                 "Urinalysis Appearance":"urinalysis Appearance",
                 "Urinalysis Leucocyte":"urinalysis Leucocyte",
                 "Urinalysis Blood":"urinalysis Blood",
                 "Urinalysis Glucose":"urinalysis Glucose",
                 "Urinalysis Ketone":"urinalysis Ketone",
                 "Urinalysis nitrite":"urinalysis nitrite",
                 "Urinalysis bilirubin":"urinalysis bilirubin",
                 "Urinalysis Urobilinogen":"urinalysis Urobilinogen",
                 "Urinalysis Ph":"urinalysis ph",
                  "Microscopy wbc/pus cells":"microscopy",
                  "Microscopy Rbc":"microscopy",
                  "Microscopy Bacteria":"microscopy",
                  "Microscopy Casts":"microscopy",
                  "Microscopy Epithelial Cells":"microscopy",
                  
                  "Stool examination Gross Apearance":"stool examination Gross Apearance",
                  "Stool examination Direct microscopy":"stool examination Direct microscopy",
                  "Pregnancy test":"pregnancy test"}
                  }
       if(jp==0):
          sa = request.form
          quer="UPDATE work SET  emp_id_l=:jp_id WHERE id = '" + str( wid) + "'"
          dk=[{"jp_id":str(sa["LABRATORIY"])}]
          insert_update_and_DELETE(quer,dk)
          tost={"1":"SECCSEFULY! "} 
          print("tost={sccus ")
           
         
       AC="/1/9/A"
   if(ID1=="5"):
     print("p")
   if(ID1=="6"):
      passw1()
      AC="/1/11/A"
   if(ID1=="7"):
     sa = request.form
     CM={"SECCSEFULY!":" "} 
     quer="SELECT p_id  ,mh_id     FROM work WHERE id= '" + sa["petionet"] + "' "   
     conj=pull(quer) 
     Y=conj.fetchone()
     y=Y[0]
     mh1=Y[1]
     wid=sa["petionet"]
     quer="SELECT fname  ,age,address,sex     FROM petionet WHERE id= '" +str( Y[0]) + "' "
     conj=pull(quer) 
     Y=conj.fetchone()
     PAA["address"]  =Y[2]
     PAA["Name"]=Y[0]
     PAA["Sex"]=Y[3]
     PAA["Age"]=Y[1]
     PAA["id"]=y
   if(ID1=="8"):
     CM={"SECCSEFULY!":" "} 
     ntc=0
     sa = request.form
     quer="UPDATE  mh SET DIAGNOSIS=:DIAGNOSIS,  PENSCRIPTION=:PENSCRIPTION, COMMENTT=:COMMENT WHERE id = '" + str( mh1) + "'" 
     dk=[{"DIAGNOSIS":sa["Diagnosis"],
           "PENSCRIPTION":sa["Prescription"],
            "COMMENT":sa["Comment"] }]
     insert_update_and_DELETE(quer,dk) 
     
     quer="DELETE FROM work WHERE id= '" + str( wid) + "'"
    
     insert_update_and_DELETE(quer,dk) 
   if(ID1=="9"):
     sa=request.form.getlist('lname')
     A=""
     for x in sa:
       A=A+x
       A=A+"\n"
     print(A)
     quer="UPDATE mh SET LABRATORIY = :LABRATORIY WHERE id = '" + str( mh1) + "'"
     
     dk=[{"LABRATORIY":A}]
     insert_update_and_DELETE(quer,dk)
     quer="UPDATE work SET jp_id=:jp_id,lab_stu='2' WHERE id = '" + str( wid) + "'"
     print("333333333333",wid)
     dk=[{"jp_id":"4"}]
     insert_update_and_DELETE(quer,dk)
     quer="SELECT fname, sname,id FROM employe  WHERE 	statuss= '1' AND jop_id='4'"
     conj=pull(quer)
     FM={"LABRATORIY":" "}
      
     bb=dict(SELECTIV(conj))
     FM["LABRATORIY"]=bb
     AC="/1/4"
     
     
   if(ID1=="10") :
     X2={}
     quer="SELECT p_id   FROM  work WHERE lab_stu ='3' AND em_id='" +str(ACC["id"]) + "'  "
     conj=pull(quer)
     
     print("lllll")
     le=0
     for x in conj:
         le=44
         print("00000000000000000000098818",x)
         quer="SELECT fname,	sname    FROM petionet WHERE id= '" +str( x[0]) + "' "
         con=pull(quer)
         Y=con.fetchone()
         x1=Y[0]+" "+Y[1]
         print("000000",x1)
         X4={x1:  "9"}
         X2.update(X4)
     LT=X2
     """
     if(le==0):
           row=conj.fetchone()
           quer="SELECT fname,	sname    FROM petionet WHERE id= '" +str(0) + "' "
           con=pull(quer)
           Y=con.fetchone()
           X2={"Name:-->"+Y[0]+" "+Y[1]:"9"}
           LT=X2 
     print("LTT",LT)
     CM={"incoming lab report is":" "}
    """




   if(ID1=="11") :
     passw2() 
   if(ID1=="12"):
     nav= {"0":"View-M-H-info",
          "1":{
               "View-M-H-info":"/1/12",
               "New M-H":"/1/3",
               "laboratory reqwest ":"/1/4"
          }
           }
     quer="SELECT DATE,	DIAGNOSIS,LABRATORIY, COMMENTT ,PENSCRIPTION   FROM mh WHERE petionet_id= '" + str( PAA["id"]) + "'"
     conj=pull(quer)
     
     m={}
     m1=1
     TB1={"a":"10"}
     for x in conj:
       x1=x[1]
       x2=x[2]
       x3=x[3]
       x4=x[4]
       x0=x[0]
       if not x[1]:
           x1="wetting......"
       if not x[2]:
           x2="wetting......"
       if not x[3]:
           x3="wetting......"
       if not x[4]:
           x4="wetting......"
       if not x[0]:
           x0="wetting......"
       m2={}
       m2["DATE"]=x0
       m2["DIAGNOSIS"]=x1
       xo="wetting......"
       
       m2["COMMENTT"]=x3
       m2["PENSCRIPTION"]=x4
       m3=str(m1)+"--"+x0
       m2["LABRATORIY"]=x2  
       m[m3]=m2
       m1=m1+1
     TB2=m
     print("POO",m)
   if(ID1=="13") :  
       comp_rest()
###############################
def l_A_B():
  global MU,FM ,AC,CM,LT,PAA,wid,mh1,x2
  global nav,tebl_ad,TG,tost,MFA,comp,TB1,TB2,ntc,la_r_c,patern
  dt= datetime.datetime.now().date()
  id=ACC["ACCT"]
  m=stu_1(id)
  dt= datetime.datetime.now().date()
  TG={
    "1":ACC["name"],
    "2":m,
    "3":dt,
    "4":'lab.JPG'
   
    }
  MFA={"Complin":"fas fa-clipboard-list", "laboratory":"fas fa-microscope","patient":"fas fa-procedures","profile":"fas fa-users","patient info":"fas fa-clipboard-list"}
  k1=in_lb_c()  
  if k1 !=0:
    
    MFA["patient"]="far fa-bell"
    if (ntc==0):
     k11="you have "+str(k1)+" "+"new patient"
     tost= {"1":k11} 
     ntc=1
  MU={"patient":"/1/1",
      "Complin":"/1/7",
      "profile":{"change password":"/1/2"}
      
      }
  if(ID1=="1"):
  
  
    la_r_c=1
    em_i="SELECT p_id,	id    FROM work WHERE jp_id='4' AND  emp_id_l='" +str(ACC["id"]) + "'  "
    worksel(em_i)
    AC="/1/3/A"
  if(ID1=="2"):
    passw1()
    AC="/1/4/A"
  if(ID1=="3"):
    nav= {"0":"laboratory",
          "1":{
               "View-p-info":"/1/6",
               
               "laboratory reqwest":"/1/3"
          }
           }
    x2={}
    if (la_r_c == 1):
        sa = request.form
        PAA["Name"]=sa["petionet"]
        la_r_c=0
  
    quer="SELECT p_id ,mh_id, em_id FROM  work WHERE id= '" +str(PAA["Name"]) + "' "
    X=pull(quer)
    X=X.fetchone()
    PAA["id"]=X[0]
    quer="SELECT fname ,sname  FROM  petionet WHERE id= '" +str(X[0]) + "' "
    X1=pull(quer)
    X1=X1.fetchone()
    nm=X1[0]+" "+X1[1]
    quer="SELECT fname ,sname  FROM  employe WHERE id= '" +str(X[2]) + "' "
    conj1=pull(quer)
    conj1=conj1.fetchone()
    nm=nm+" " +"Labratoriy request from"+" "+conj1[0]+" "+conj1[1]
    CM={"Name":nm}
    quer="SELECT LABRATORIY  FROM  mh WHERE id= '" +str(X[1]) + "' "
    Y=pull(quer)
    Y=Y.fetchone()
    y=Y[0]
    print("uuuu",str(X[1]))
    for x in y.split("\n"):
      patern={str(x):"[A-Za-z0-9]{1,1000}"}
      x1={x:"1"}
      x2.update(x1)
    x2.popitem()
    print("uu1",x2)
    FM=x2
    mh1=X[1]
    wid=PAA["Name"]
    AC="/1/5/A" 
  if(ID1=="4"):
    passw2() 
  if(ID1=="5"):
    sa = request.form
    CM={"SECCSEFULY!":" "}
    A=""
    print(x2)
    for x,y in x2.items():
         A = A + x + "=" + sa.get(x, "Key Not Found")

         A=A+"\n"
    print(A)
    A=A.rstrip('\n')
    quer="UPDATE mh SET LABRATORIY = '" + A + "' WHERE id = :id"
    dk=[{"id":mh1}]
    insert_update_and_DELETE(quer,dk)
    quer="UPDATE work SET jp_id = '3', 	lab_stu ='3' WHERE id = :user_id"
    dk=[{"user_id":wid}]
    insert_update_and_DELETE(quer,dk)
  if(ID1=="6"):
       nav= {"0":"View-p-info",
          "1":{
               "View-p-info":"/1/6",
               
               "laboratory reqwest":"/1/3"
          }
           }
       TB1={"a":"11"}
       x=PAA["id"]
       list_pp(x)
  if(ID1=="7"):
    comp_rest()
###############################
def P_pharmacy():
  global MU,FM ,AC,CM,nav,tebl_ad,TG,tost,MFA,comp,TB1,TB2,la_r_c
  global LT
  dt= datetime.datetime.now().date()
  id=ACC["ACCT"]
  m=stu_1(id)
  dt= datetime.datetime.now().date()
  TG={
    "1":ACC["name"],
    "2":m,
    "3":dt,
    "4":'phr.PNG'
   
    }
  MFA={ "Complin":"fas fa-clipboard-list","laboratory":"fas fa-microscope","patient":"fas fa-procedures","profile":"fas fa-users","patient info":"fas fa-clipboard-list"}
  
  MU={"patient":"/1/1",
      "Complin":"/1/6",
      "profile":{"change password":"/1/2"}}
  if(ID1=="1"):
    la_r_c=1
    xk="SELECT petionet_id ,id FROM mh WHERE DATE='2024-04-18'"
    em_i="SELECT petionet_id,id FROM mh WHERE  DATE='" + str(dt) + "'" 
    worksel(em_i)
    AC="/1/3/A"
  if(ID1=="2"):
    passw1()
    AC="/1/4/A"
  if(ID1=="3") :
    nav= {"0":"Penscription",
          "1":{
               "View-p-info":"/1/5",
               
               "Penscription":"/1/3"
          }
           }
    x2={}
    if (la_r_c == 1):
        sa = request.form
        PAA["Name"]=sa["petionet"]
        la_r_c=0
  
    quer="SELECT petionet_id ,PENSCRIPTION, employe_id  FROM  mh WHERE id= '" +str(PAA["Name"]) + "' "
    X=pull(quer)
    X=X.fetchone()
    PAA["id"]=X[0]
    quer="SELECT fname ,sname  FROM  petionet WHERE id= '" +str(X[0]) + "' "
    X1=pull(quer)
    X1=X1.fetchone()
    nm=X1[0]+" "+X1[1]
    quer="SELECT fname ,sname  FROM  employe WHERE id= '" +str(X[2]) + "' "
    conj1=pull(quer)
    conj1=conj1.fetchone()
    nm=nm+" " +"Penscription  from"+" "+conj1[0]+" "+conj1[1]
    CM={"Name":nm}
    
    TB1={"a":"15"}
    TB2["Penscription"]=X[1]
   
   
    
    
  if(ID1=="4") :
    passw2()
  if(ID1=="5"):
       nav= {"0":"View-p-info",
          "1":{
               "View-p-info":"/1/6",
               
               "Penscription":"/1/3"
          }
           }
       TB1={"a":"11"}
       x=PAA["id"]
       list_pp(x)
  if(ID1=="6"):
    comp_rest()
    

def post_get():
 p=9   # Your code that may raise a "Method Not Allowed" error
 if request.method == 'POST':
            # Process GET request
            p=0
            print("SAM")
 elif request.method == 'GET':
            p=1
 return p
app = Flask(__name__)

def log_cont(ID):
   global ID1,MU,FM,CM,AC,TB1,TB2,LT,nav,tebl_ad,TG,tost,MFA,comp,patern,comp_t,l_t ,sb_minput,tb_ab1,jp
   jp=post_get()             
   befr()
   ID1=str(ID)
   if(ACC["ACCT"]=="1"):
        admin()
   if(ACC["ACCT"]=="2"):
        cardroom()
   if(ACC["ACCT"]=="3"):
        o_P_D()
   if(ACC["ACCT"]=="4"):
        l_A_B()
   if(ACC["ACCT"]=="5"):
        P_pharmacy()
   ID1="0"
  

LT={}

@app.route("/", methods=['GET',"POST"])

def hello_world():
 

  global LG,CM,TB1,TB2,LT,nav,tebl_ad,TG,tost,MFA,comp,ntc,patern,jp ,comp_t,l_t,sb_minput,ACC,tb_ab1
  ACC={"name":"0",
     "id":"0",
     "stu":"0",
     "pw":"0",
      "ACCT":"0"}      
  jp=post_get()             
  
  
  befr()
  ntc=0
  print("hi all it is servare 5000")
  
  CM={"INSERT":""}
  
 
  return render_template('log.html',MU=MU,FM=FM,CM=CM,LG=LG,TB1=TB1,TB2=TB2,LT=LT,nav=nav,xt=tebl_ad, TG=TG ,tost=tost,MFA=MFA ,comp=comp ,patern=patern,comp_t=comp_t,l_t =l_t,sb_minput=sb_minput,tb_ab1=tb_ab1 )
 
@app.route("/<AC1>", methods=['GET',"POST"])
def helloworld(AC1):
 global CM,ACC,MU,FM,TB1,TB2,LT,nav,tebl_ad,TG,tost,MFA,comp,patern,jp,comp_t,l_t ,sb_minput,tb_ab1
 print("jjj",l_t)
 jp=post_get() 
 befr()

  

 sa = request.form
 ACC["name"]=sa["User Name"]
 ACC["pw"]=sa["psw"]
 CP="7"
 CM={}
 LG="1"
 X=()
 quer="SELECT id, statuss, fname,jop_id FROM employe WHERE fname = '" + sa["User Name"] + "' AND pw = '" + sa["psw"] + "'"
 conj=pull(quer)
 for x in conj:
    X=x
 if len(X) == 0:
    CM={"incorect pasword or user name ":" "}
    print("List is empty")
 else:
    print("List is not empty")
    print(conj)
    ACC["id"]=X[0]
    ACC["stu"]=X[1]
    ACC["ACCT"]=str(X[3])
    
    for item in conj:
      for element in item:
        print(element)
    if ACC["stu"]==0:
      CM={"your aconnt is an avelebel":" "}
    if ACC["stu"]==1:
      befr()
      P="welcome "+X[2]
      CM={P:" "}
      if(ACC["ACCT"]=="1"):
         admin()
      if(ACC["ACCT"]=="2"):
        cardroom()
      if(ACC["ACCT"]=="3"):
        o_P_D()
      if(ACC["ACCT"]=="4"):
        l_A_B()
      if(ACC["ACCT"]=="5"):
        P_pharmacy()
 
 return render_template('sol.html', MU=MU ,FM=FM,CM=CM,TB1=TB1,TB2=TB2,LT=LT,nav=nav,xt=tebl_ad,TG=TG,tost=tost,MFA=MFA,comp=comp,patern=patern,comp_t=comp_t,l_t =l_t ,sb_minput=sb_minput,tb_ab1=tb_ab1)     

  

 

   
  
@app.route("/<AC1>/<ID>",methods=['GET',"POST"] )
def hellid(AC1,ID):
  global ACC,CM
  if(ACC["ACCT"]=="0"):
    CM={"STIV":"J"}
  else:
   log_cont(ID)
   
  
   return render_template('sol.html', MU=MU ,FM=FM,CM=CM,AC=AC,TB1=TB1,TB2=TB2,LT=LT,nav=nav ,xt=tebl_ad,TG=TG,tost=tost,MFA=MFA,comp=comp,patern=patern,comp_t=comp_t,l_t =l_t ,sb_minput=sb_minput,tb_ab1=tb_ab1)
@app.route("/<AC1>/<ID>/<A>",methods=['GET',"POST"])
def hellid1(AC1,ID,A):
  global ACC,CM
  if(ACC["ACCT"]=="0"):
    CM={"STIV":"J"}
  else:
   log_cont(ID)
   
  
   return render_template('sol.html', MU=MU ,FM=FM,CM=CM,AC=AC,TB1=TB1,TB2=TB2,LT=LT,nav=nav ,xt=tebl_ad,TG=TG,tost=tost,MFA=MFA,comp=comp ,patern=patern,comp_t=comp_t,l_t =l_t,sb_minput=sb_minput,tb_ab1=tb_ab1 )


     
    

if __name__ == "__main__":
  app.run(host='0.0.0.0',debug=True) 

     
    

  
   


  
  




