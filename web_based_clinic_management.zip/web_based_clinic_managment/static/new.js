const search =()=>{
  const sb=document.getElementById("searchButton").value.toLowerCase();
  const sttoritems=document.getElementById("table-container")
  const prodact=document.querySelectorAll(". basic-table")
  const pname = storeitems.getElementByIdTagName("td")
  for (var i=0; i< pname.length; i++){
	  let match=prodact[i].getElementByIdTagName("")[0];
	  
	  if(match){
		  let textval= match.textContent || match.innerHTML
		  if(textval.toLowerCase().indexOf(sb)>-1){
		  prodact[i].style.display=""}
		  else{
			   prodact[i].style.display="none"
		  }
	  }
  }
}